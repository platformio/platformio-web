#include <iostream>

int main(int argc, char const *argv[]) {
    return i;
}
