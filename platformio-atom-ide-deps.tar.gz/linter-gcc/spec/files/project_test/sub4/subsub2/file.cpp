#include <iostream>

int main(int argc, char const *argv[]) {
    /* code */
    return 0;
}
